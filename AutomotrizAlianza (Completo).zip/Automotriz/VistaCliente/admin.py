from django.contrib import admin
from .models import Marca, Year, Auto, Publicacion,Cliente, Venta, Informe_Compra_Venta, Contacto,AutoImage,Combustible,Transmisión
class MarcaAdmin(admin.ModelAdmin):
    list_display = ['nombre']

class YearAdmin(admin.ModelAdmin):
    list_display = ['year']

class AutoAdmin(admin.ModelAdmin):
    list_display = ['modelo', 'year', 'marca']

class ContactoAdmin(admin.ModelAdmin):
    list_display = ['nombre','correo','descripcion','id_publicación']

class VentaAdmin(admin.ModelAdmin):
    list_display = ['fecha','id_publicación','id_cliente']

# Register your models here.
admin.site.register(Marca,MarcaAdmin)
admin.site.register(Year,YearAdmin)
admin.site.register(Auto,AutoAdmin)
admin.site.register(Publicacion)
admin.site.register(Cliente)
admin.site.register(Venta,VentaAdmin)
admin.site.register(Informe_Compra_Venta)
admin.site.register(Contacto,ContactoAdmin)
admin.site.register(AutoImage)
admin.site.register(Combustible)
admin.site.register(Transmisión)
